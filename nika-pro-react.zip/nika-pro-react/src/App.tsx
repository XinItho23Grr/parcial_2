import React, { useState, useEffect } from "react";
import initialProductsData from "./productsData.json";
import { Navbar } from "./components/Navbar";
import { Footer } from "./components/Footer";

// Vistas
import { InicioView } from "./views/inicio/page";
import { ProductosView, Product } from "./views/productos/page";
import { DetalleProductoView } from "./views/detalle-producto/page";
import { LoginView } from "./views/login/page";
import { RegistroView } from "./views/registro/page";
import { NosotrosView } from "./views/nosotros/page";
import { ContactoView } from "./views/contacto/page";
import { CartView, CartItem } from "./views/cart/page";
import { AdminDashboardView } from "./views/admin/DashboardView";

interface User {
  id: string;
  nombre: string;
  correo: string;
  rut?: string;
  role: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState("inicio");
  const [filterText, setFilterText] = useState("");
  const [inStockOnly, setInStockOnly] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem("nika_cart");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const session = localStorage.getItem("nika_session");
      return session ? JSON.parse(session) : null;
    } catch {
      return null;
    }
  });

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const savedProds = localStorage.getItem("nika_products");
      if (savedProds) return JSON.parse(savedProds);
    } catch {}
    return initialProductsData.products || [];
  });

  useEffect(() => {
    localStorage.setItem("nika_cart", JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    localStorage.setItem("nika_products", JSON.stringify(products));
  }, [products]);

  // Actualizador de stock numérico para el Admin
  const handleUpdateStockQuantity = (id: string, newStock: number) => {
    setProducts((prev) =>
      prev.map((p) =>
        p.id === id
          ? { ...p, stockQuantity: newStock, stocked: newStock > 0 }
          : p
      )
    );
  };

  const handleAddProduct = (newProd: Product) => {
    setProducts((prev) => [newProd, ...prev]);
    alert("¡Producto agregado al inventario!");
  };

  const handleUpdateProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm("¿Estás seguro de eliminar este producto del catálogo?")) {
      setProducts((prev) => prev.filter((p) => p.id !== id));
    }
  };

  const handleAddToCart = (prod: Product) => {
    if (currentUser?.role === "admin") {
      alert("El perfil de administrador gestiona el inventario, no realiza compras.");
      return;
    }
    setCartItems((prev) => {
      const existing = prev.find((i) => i.id === prod.id);
      if (existing) {
        return prev.map((i) => (i.id === prod.id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [...prev, { id: prod.id, name: prod.name, price: prod.price, image: prod.image, quantity: 1 }];
    });
    alert(`¡"${prod.name}" agregado al carrito!`);
  };

  const handleLogout = () => {
    localStorage.removeItem("nika_session");
    setCurrentUser(null);
    setActiveTab("inicio");
    alert("Sesión cerrada correctamente.");
  };

  return (
    <div className="d-flex flex-column min-vh-100 bg-light">
      <Navbar
        filterText={filterText}
        setFilterText={setFilterText}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      <main className="container my-4 flex-grow-1">
        {activeTab === "inicio" && <InicioView onVerProductos={() => setActiveTab("productos")} />}

        {activeTab === "productos" && (
          <ProductosView
            products={products}
            filterText={filterText}
            inStockOnly={inStockOnly}
            setInStockOnly={setInStockOnly}
            currentUser={currentUser}
            onSelectProduct={(prod) => {
              setSelectedProduct(prod);
              setActiveTab("detalle");
            }}
            onAddToCart={handleAddToCart}
            onUpdateStockQuantity={handleUpdateStockQuantity}
            onDeleteProduct={handleDeleteProduct}
          />
        )}

        {activeTab === "detalle" && (
  <DetalleProductoView
    product={selectedProduct}
    currentUser={currentUser}
    onVolver={() => setActiveTab("productos")}
    onAddToCart={handleAddToCart}
    onUpdateStockQuantity={handleUpdateStockQuantity}
    onDeleteProduct={handleDeleteProduct}
  />
)}

        {activeTab === "cart" && currentUser?.role !== "admin" && (
          <CartView
            cartItems={cartItems}
            currentUser={currentUser}
            onUpdateQuantity={(id, delta) =>
              setCartItems((prev) =>
                prev.map((i) => (i.id === id ? { ...i, quantity: Math.max(0, i.quantity + delta) } : i)).filter((i) => i.quantity > 0)
              )
            }
            onRemoveItem={(id) => setCartItems((prev) => prev.filter((i) => i.id !== id))}
            onClearCart={() => setCartItems([])}
            onVolverAlCatalogo={() => setActiveTab("productos")}
          />
        )}

        {activeTab === "login" && <LoginView onIrARegistro={() => setActiveTab("registro")} />}
        {activeTab === "registro" && <RegistroView onIrALogin={() => setActiveTab("login")} />}
        {activeTab === "nosotros" && <NosotrosView />}
        {activeTab === "contacto" && <ContactoView />}

        {activeTab === "admin" && currentUser?.role === "admin" && (
          <AdminDashboardView
            products={products}
            onAddProduct={handleAddProduct}
            onUpdateProduct={handleUpdateProduct}
            onDeleteProduct={handleDeleteProduct}
          />
        )}
      </main>

      <Footer setActiveTab={setActiveTab} />
    </div>
  );
}