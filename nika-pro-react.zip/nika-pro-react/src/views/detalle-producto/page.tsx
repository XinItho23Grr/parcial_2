import React from "react";
import { Product } from "../productos/page";

interface DetalleProps {
  product: Product | null;
  currentUser: { role: string } | null;
  onVolver: () => void;
  onAddToCart: (prod: Product) => void;
  onUpdateStockQuantity?: (id: string, newStock: number) => void;
  onDeleteProduct?: (id: string) => void;
}

export const DetalleProductoView: React.FC<DetalleProps> = ({
  product,
  currentUser,
  onVolver,
  onAddToCart,
  onUpdateStockQuantity,
  onDeleteProduct,
}) => {
  if (!product) {
    return (
      <div className="text-center py-5">
        <h4>No se ha seleccionado ningún producto.</h4>
        <button className="btn btn-dark mt-3" onClick={onVolver}>
          Volver
        </button>
      </div>
    );
  }

  const esAdmin = currentUser?.role === "admin";
  const cantidadStock = product.stockQuantity ?? (product.stocked ? 5 : 0);

  return (
    <div className="row justify-content-center">
      <div className="col-md-9">
        <button className="btn btn-outline-secondary btn-sm mb-3" onClick={onVolver}>
          ← Volver atrás
        </button>

        <div className="card shadow-sm border-0 p-4 bg-white">
          <div className="row g-4 align-items-center">
            <div className="col-md-5 text-center">
              <img
                src={product.image}
                alt={product.name}
                className="img-fluid p-2"
                style={{ maxHeight: "300px", objectFit: "contain" }}
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    "https://via.placeholder.com/300?text=Sin+Imagen";
                }}
              />
            </div>
            <div className="col-md-7">
              <span className="badge bg-secondary mb-2">{product.category}</span>
              <h2 className="fw-bold text-dark">{product.name}</h2>
              <p className="text-danger fw-bold fs-3 mb-3">{product.price}</p>
              
              <p className="text-muted">
                Componente de alto rendimiento seleccionado para el catálogo de Nika Gamer Store.
              </p>

              <div className="mb-4">
                <span className={cantidadStock > 0 ? "text-success fw-bold" : "text-danger fw-bold"}>
                  {cantidadStock > 0 ? `✓ Stock disponible: ${cantidadStock} unidades` : "✕ Producto agotado"}
                </span>
              </div>

              {/* Si es Admin muestra control de stock; si es Cliente muestra agregar al carrito */}
              {esAdmin ? (
                <div className="card bg-light p-3 border">
                  <h6 className="fw-bold text-dark mb-2">⚙️ Panel de Gestión Rápida (Admin)</h6>
                  <div className="input-group input-group-sm mb-3" style={{ maxWidth: "220px" }}>
                    <span className="input-group-text">Modificar Stock:</span>
                    <input
                      type="number"
                      min="0"
                      className="form-control text-center fw-bold"
                      value={cantidadStock}
                      onChange={(e) =>
                        onUpdateStockQuantity &&
                        onUpdateStockQuantity(product.id, parseInt(e.target.value, 10) || 0)
                      }
                    />
                  </div>
                  <button
                    className="btn btn-outline-danger btn-sm fw-bold w-50"
                    onClick={() => {
                      if (onDeleteProduct) {
                        onDeleteProduct(product.id);
                        onVolver();
                      }
                    }}
                  >
                    🗑️ Eliminar Producto del Catálogo
                  </button>
                </div>
              ) : (
                <button
                  className="btn btn-danger fw-bold px-4 py-2"
                  disabled={cantidadStock <= 0}
                  onClick={() => onAddToCart(product)}
                >
                  🛒 Agregar al Carrito
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};