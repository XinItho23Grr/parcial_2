import React, { useState } from "react";
import { Product } from "../productos/page";

interface Order {
  id: string;
  cliente: string;
  total: string;
  fecha: string;
  estado: "Pendiente" | "Enviado" | "Entregado";
}

interface AdminDashboardProps {
  products: Product[];
  onAddProduct: (prod: Product) => void;
  onUpdateProduct: (updated: Product) => void;
  onDeleteProduct: (id: string) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardProps> = ({
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
}) => {
  // Datos simulados de órdenes de venta
  const [orders, setOrders] = useState<Order[]>([
    { id: "ORD-101", cliente: "Carlos Mendoza", total: "$580.000", fecha: "2026-10-25", estado: "Pendiente" },
    { id: "ORD-102", cliente: "Ana María Silva", total: "$296.990", fecha: "2026-10-26", estado: "Enviado" },
    { id: "ORD-103", cliente: "Hitoshen Hayashi", total: "$1.250.000", fecha: "2026-10-27", estado: "Entregado" },
  ]);

  // Edición rápida de producto
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Product>>({});

  // Formulario de nuevo producto
  const [newForm, setNewForm] = useState({
    name: "",
    category: "Tarjetas Gráficas",
    price: "",
    image: "/img/",
    description: "",
    stocked: true,
  });

  // Usuarios registrados desde localStorage
  const clientesRegistrados = JSON.parse(localStorage.getItem("nika_users") || "[]");

  // Métricas
  const totalStock = products.filter((p) => p.stocked).length;
  const sinStock = products.length - totalStock;

  const cambiarEstadoOrden = (id: string, nuevoEstado: "Pendiente" | "Enviado" | "Entregado") => {
    setOrders((prev) =>
      prev.map((o) => (o.id === id ? { ...o, estado: nuevoEstado } : o))
    );
  };

  const handleStartEdit = (p: Product) => {
    setEditingId(p.id);
    setEditForm(p);
  };

  const handleSaveEdit = () => {
    if (editingId && editForm.name) {
      onUpdateProduct(editForm as Product);
      setEditingId(null);
    }
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const created: Product = {
      id: Date.now().toString(),
      name: newForm.name,
      category: newForm.category,
      price: newForm.price.startsWith("$") ? newForm.price : `$${newForm.price}`,
      image: newForm.image || "/img/default.jpg",
      stocked: newForm.stocked,
    };
    onAddProduct(created);
    setNewForm({ name: "", category: "Tarjetas Gráficas", price: "", image: "/img/", description: "", stocked: true });
  };

  return (
    <div className="container py-2">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 className="fw-bold text-dark m-0">⚙️ Panel de Administración General</h2>
          <small className="text-muted">Visión general de métricas, ventas e inventario</small>
        </div>
        <span className="badge bg-danger px-3 py-2 fs-6">Administrador: HH20059232</span>
      </div>

      {/* Tarjetas de Métricas (KPIs) */}
      <div className="row g-3 mb-4">
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3 bg-primary text-white">
            <span className="small text-uppercase">Ventas Totales</span>
            <h3 className="fw-bold m-0">$2.126.990</h3>
            <small>3 Órdenes registradas</small>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3 bg-warning text-dark">
            <span className="small text-uppercase">Órdenes Pendientes</span>
            <h3 className="fw-bold m-0">{orders.filter((o) => o.estado === "Pendiente").length}</h3>
            <small>Por despachar</small>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3 bg-success text-white">
            <span className="small text-uppercase">Stock Disponible</span>
            <h3 className="fw-bold m-0">{totalStock} / {products.length}</h3>
            <small>{sinStock} Ítems agotados</small>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3 bg-dark text-white">
            <span className="small text-uppercase">Clientes Registrados</span>
            <h3 className="fw-bold m-0">{clientesRegistrados.length}</h3>
            <small>Usuarios activos</small>
          </div>
        </div>
      </div>

      {/* Gráfico Visual de Ventas y Categorías */}
      <div className="row g-4 mb-4">
        <div className="col-lg-6">
          <div className="card border-0 shadow-sm p-4 bg-white h-100">
            <h5 className="fw-bold mb-3">📈 Reporte Visual de Ventas Mensuales</h5>
            <div className="d-flex align-items-end gap-3 justify-content-between pt-4" style={{ height: "180px" }}>
              <div className="text-center flex-grow-1">
                <div className="bg-secondary rounded-top" style={{ height: "40px" }}></div>
                <small className="d-block mt-2">Julio</small>
              </div>
              <div className="text-center flex-grow-1">
                <div className="bg-secondary rounded-top" style={{ height: "70px" }}></div>
                <small className="d-block mt-2">Agosto</small>
              </div>
              <div className="text-center flex-grow-1">
                <div className="bg-secondary rounded-top" style={{ height: "110px" }}></div>
                <small className="d-block mt-2">Septiembre</small>
              </div>
              <div className="text-center flex-grow-1">
                <div className="bg-danger rounded-top fw-bold text-white small pt-1" style={{ height: "150px" }}>
                  $2.1M
                </div>
                <small className="d-block mt-2 fw-bold text-danger">Octubre</small>
              </div>
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="card border-0 shadow-sm p-4 bg-white h-100">
            <h5 className="fw-bold mb-3">🏷️ Distribución por Categoría</h5>
            <div className="d-flex flex-column gap-3">
              <div>
                <div className="d-flex justify-content-between small fw-semibold mb-1">
                  <span>Tarjetas Gráficas</span>
                  <span>40%</span>
                </div>
                <div className="progress" style={{ height: "10px" }}>
                  <div className="progress-bar bg-danger" style={{ width: "40%" }}></div>
                </div>
              </div>
              <div>
                <div className="d-flex justify-content-between small fw-semibold mb-1">
                  <span>Procesadores</span>
                  <span>25%</span>
                </div>
                <div className="progress" style={{ height: "10px" }}>
                  <div className="progress-bar bg-primary" style={{ width: "25%" }}></div>
                </div>
              </div>
              <div>
                <div className="d-flex justify-content-between small fw-semibold mb-1">
                  <span>Almacenamiento y Memorias</span>
                  <span>20%</span>
                </div>
                <div className="progress" style={{ height: "10px" }}>
                  <div className="progress-bar bg-warning" style={{ width: "20%" }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Gestión de Órdenes Pendientes */}
      <div className="card border-0 shadow-sm p-4 bg-white mb-4">
        <h5 className="fw-bold mb-3">🚚 Gestión de Órdenes y Entregas</h5>
        <div className="table-responsive">
          <table className="table table-hover align-middle">
            <thead>
              <tr>
                <th>N° Orden</th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Monto</th>
                <th>Estado</th>
                <th className="text-end">Cambiar Estado</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id}>
                  <td className="fw-bold">{o.id}</td>
                  <td>{o.cliente}</td>
                  <td>{o.fecha}</td>
                  <td className="fw-bold text-danger">{o.total}</td>
                  <td>
                    <span
                      className={`badge ${
                        o.estado === "Entregado"
                          ? "bg-success"
                          : o.estado === "Enviado"
                          ? "bg-primary"
                          : "bg-warning text-dark"
                      }`}
                    >
                      {o.estado}
                    </span>
                  </td>
                  <td className="text-end">
                    <select
                      className="form-select form-select-sm d-inline-block w-auto"
                      value={o.estado}
                      onChange={(e) => cambiarEstadoOrden(o.id, e.target.value as any)}
                    >
                      <option value="Pendiente">Pendiente</option>
                      <option value="Enviado">Enviado</option>
                      <option value="Entregado">Entregado</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Formulario y Tabla de Gestión de Inventario */}
      <div className="row g-4 mb-4">
        <div className="col-lg-4">
          <div className="card border-0 shadow-sm p-4 bg-white">
            <h5 className="fw-bold mb-3">➕ Agregar Nuevo Producto</h5>
            <form onSubmit={handleCreateProduct}>
              <div className="mb-2">
                <label className="form-label small fw-semibold">Nombre del Componente</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  required
                  value={newForm.name}
                  onChange={(e) => setNewForm({ ...newForm, name: e.target.value })}
                  placeholder="Ej: RTX 5080 16GB"
                />
              </div>
              <div className="mb-2">
                <label className="form-label small fw-semibold">Categoría</label>
                <select
                  className="form-select form-select-sm"
                  value={newForm.category}
                  onChange={(e) => setNewForm({ ...newForm, category: e.target.value })}
                >
                  <option value="Tarjetas Gráficas">Tarjetas Gráficas</option>
                  <option value="Procesadores">Procesadores</option>
                  <option value="Memoria RAM">Memoria RAM</option>
                  <option value="Almacenamiento">Almacenamiento</option>
                  <option value="Refrigeración">Refrigeración</option>
                </select>
              </div>
              <div className="mb-2">
                <label className="form-label small fw-semibold">Precio ($)</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  required
                  value={newForm.price}
                  onChange={(e) => setNewForm({ ...newForm, price: e.target.value })}
                  placeholder="$350.000"
                />
              </div>
              <div className="mb-2">
                <label className="form-label small fw-semibold">Ruta Imagen (/img/archivo.jpg)</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  value={newForm.image}
                  onChange={(e) => setNewForm({ ...newForm, image: e.target.value })}
                />
              </div>
              <div className="form-check mb-3">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="stockCheckNew"
                  checked={newForm.stocked}
                  onChange={(e) => setNewForm({ ...newForm, stocked: e.target.checked })}
                />
                <label className="form-check-label small" htmlFor="stockCheckNew">
                  Disponible en Stock
                </label>
              </div>
              <button type="submit" className="btn btn-danger btn-sm w-100 fw-bold">
                Guardar en Inventario
              </button>
            </form>
          </div>
        </div>

        <div className="col-lg-8">
          <div className="card border-0 shadow-sm p-4 bg-white">
            <h5 className="fw-bold mb-3">📦 Edición de Stock y Precios</h5>
            <div className="table-responsive" style={{ maxHeight: "400px", overflowY: "auto" }}>
              <table className="table align-middle table-sm">
                <thead>
                  <tr>
                    <th>Imagen</th>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th className="text-end">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((p) => (
                    <tr key={p.id}>
                      <td>
                        <img src={p.image} alt={p.name} style={{ width: "35px", height: "35px", objectFit: "contain" }} />
                      </td>
                      <td>
                        {editingId === p.id ? (
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            value={editForm.name}
                            onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                          />
                        ) : (
                          <span className="small fw-semibold">{p.name}</span>
                        )}
                      </td>
                      <td>
                        {editingId === p.id ? (
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            value={editForm.price}
                            onChange={(e) => setEditForm({ ...editForm, price: e.target.value })}
                          />
                        ) : (
                          <span className="small fw-bold text-danger">{p.price}</span>
                        )}
                      </td>
                      <td>
                        <button
                          className={`badge border-0 ${p.stocked ? "bg-success" : "bg-danger"}`}
                          onClick={() => onUpdateProduct({ ...p, stocked: !p.stocked })}
                        >
                          {p.stocked ? "En Stock" : "Sin Stock"}
                        </button>
                      </td>
                      <td className="text-end">
                        {editingId === p.id ? (
                          <button className="btn btn-sm btn-success me-1" onClick={handleSaveEdit}>
                            💾
                          </button>
                        ) : (
                          <button className="btn btn-sm btn-outline-secondary me-1" onClick={() => handleStartEdit(p)}>
                            ✏️
                          </button>
                        )}
                        <button className="btn btn-sm btn-outline-danger" onClick={() => onDeleteProduct(p.id)}>
                          🗑️
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Registro de Clientes */}
      <div className="card border-0 shadow-sm p-4 bg-white">
        <h5 className="fw-bold mb-3">👥 Clientes Registrados en la Plataforma</h5>
        {clientesRegistrados.length === 0 ? (
          <p className="text-muted m-0 small">No hay nuevos clientes registrados en el navegador.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-sm align-middle">
              <thead>
                <tr>
                  <th>ID Usuario</th>
                  <th>Nombre</th>
                  <th>RUT</th>
                  <th>Correo</th>
                  <th>Rol</th>
                </tr>
              </thead>
              <tbody>
                {clientesRegistrados.map((u: any, idx: number) => (
                  <tr key={idx}>
                    <td className="fw-bold">{u.id}</td>
                    <td>{u.nombre}</td>
                    <td>{u.rut}</td>
                    <td>{u.correo}</td>
                    <td><span className="badge bg-secondary">{u.role}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};