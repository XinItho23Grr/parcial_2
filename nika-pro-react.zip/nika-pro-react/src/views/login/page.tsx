import React, { useState } from "react";

interface LoginProps {
  onIrARegistro: () => void;
}

export const LoginView: React.FC<LoginProps> = ({ onIrARegistro }) => {
  const [userIdInput, setUserIdInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    // Convertir automáticamente las letras a mayúsculas (ej: hh20059232 -> HH20059232)
    const userId = userIdInput.trim().toUpperCase();
    const password = passwordInput.trim();

    // 1. Verificación de Administrador Principal Requerido
    if (userId === "HH20059232" && password === "20059232HH") {
      const adminUser = {
        id: "HH20059232",
        nombre: "Hitoshen Hayashi (Admin)",
        correo: "hitoshen.admin@nika.cl",
        role: "admin",
      };
      localStorage.setItem("nika_session", JSON.stringify(adminUser));
      alert("¡Bienvenido Administrador Hitoshen!");
      window.location.reload(); // Recarga para aplicar sesión global
      return;
    }

    // 2. Verificar en los usuarios registrados en localStorage
    const usuariosRegistrados = JSON.parse(localStorage.getItem("nika_users") || "[]");
    const usuarioEncontrado = usuariosRegistrados.find(
      (u: any) => u.id.toUpperCase() === userId && u.password === password
    );

    if (usuarioEncontrado) {
      localStorage.setItem("nika_session", JSON.stringify(usuarioEncontrado));
      alert(`¡Bienvenido de nuevo, ${usuarioEncontrado.nombre}!`);
      window.location.reload();
      return;
    }

    setErrorMsg("ID de usuario o contraseña incorrectos. Inténtalo nuevamente.");
  };

  return (
    <div className="row justify-content-center">
      <div className="col-md-5">
        <div className="card shadow-sm p-4 bg-white border-0">
          <h2 className="h4 fw-bold text-center mb-4">🔐 Iniciar Sesión en Nika Gamer</h2>

          {errorMsg && <div className="alert alert-danger text-center">{errorMsg}</div>}

          <form onSubmit={handleLogin}>
            <div className="mb-3">
              <label className="form-label fw-semibold">ID de Usuario (Ej: AA123456789)</label>
              <input
                type="text"
                className="form-control"
                required
                value={userIdInput}
                onChange={(e) => setUserIdInput(e.target.value)}
                placeholder="Ingresa tu ID de usuario"
              />
              <div className="form-text">Si escribes en minúsculas, se pasará a mayúsculas automáticamente.</div>
            </div>

            <div className="mb-3">
              <label className="form-label fw-semibold">Contraseña</label>
              <input
                type="password"
                className="form-control"
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Ingresa tu contraseña"
              />
            </div>

            <button type="submit" className="btn btn-danger w-100 fw-bold mt-2">
              Ingresar
            </button>
          </form>

          <div className="text-center mt-3">
            <small className="text-muted">
              ¿No tienes cuenta?{" "}
              <button className="btn btn-link p-0 text-danger text-decoration-none fw-semibold" onClick={onIrARegistro}>
                Regístrate aquí
              </button>
            </small>
          </div>
        </div>
      </div>
    </div>
  );
};
