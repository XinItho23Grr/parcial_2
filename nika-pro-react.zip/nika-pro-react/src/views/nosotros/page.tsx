import React from "react";

export const NosotrosView: React.FC = () => {
  return (
    <div className="card shadow-sm p-4 bg-white border-0">
      <h2 className="h4 fw-bold mb-3">🎮 Sobre Nika Gamer Store</h2>
      <p className="text-secondary">
        Somos una tienda chilena especializada en hardware y accesorios de alto rendimiento para jugadores apasionados y creadores de contenido.
      </p>
      <div className="row my-4">
        <div className="col-md-6 mb-3">
          <div className="p-3 border rounded bg-light">
            <h5 className="fw-bold text-danger">Misión</h5>
            <p className="m-0 text-muted">Ofrecer los mejores productos tecnológicos con asesoría transparente y precios competitivos.</p>
          </div>
        </div>
        <div className="col-md-6 mb-3">
          <div className="p-3 border rounded bg-light">
            <h5 className="fw-bold text-danger">Visión</h5>
            <p className="m-0 text-muted">Ser la comunidad y tienda gamer de referencia en Chile para la adquisición de componentes.</p>
          </div>
        </div>
      </div>
    </div>
  );
};