import React, { useState } from "react";

export interface CartItem {
  id: string;
  name: string;
  price: string;
  image?: string;
  quantity: number;
}

interface CartViewProps {
  cartItems: CartItem[];
  currentUser: { id: string; nombre: string; rut?: string; correo?: string } | null;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  onVolverAlCatalogo: () => void;
}

export const CartView: React.FC<CartViewProps> = ({
  cartItems,
  currentUser,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onVolverAlCatalogo,
}) => {
  const [formData, setFormData] = useState({
    nombre: "",
    apellido: "",
    rut: "",
    telefono: "",
    direccion: "",
    numero: "",
    comuna: "",
    ciudad: "",
    metodoPago: "webpay",
  });

  const [usarDatosRegistro, setUsarDatosRegistro] = useState(false);
  const [pedidoEnviado, setPedidoEnviado] = useState(false);

  // Manejador del Checkbox / Selector "Usar mis datos de registro"
  const handleToggleDatosRegistro = (e: React.ChangeEvent<HTMLInputElement>) => {
    const checked = e.target.checked;
    setUsarDatosRegistro(checked);

    if (checked && currentUser) {
      const partesNombre = currentUser.nombre.trim().split(" ");
      const nombreOnly = partesNombre[0] || "";
      const apellidoOnly = partesNombre.slice(1).join(" ") || "";

      setFormData((prev) => ({
        ...prev,
        nombre: nombreOnly,
        apellido: apellidoOnly,
        rut: currentUser.rut || "",
      }));
    }
  };

  const parsePrice = (priceStr: string) => {
    return parseInt(priceStr.replace(/\D/g, ""), 10) || 0;
  };

  const totalCompra = cartItems.reduce(
    (acc, item) => acc + parsePrice(item.price) * item.quantity,
    0
  );

  const handleSubmitSolicitud = (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItems.length === 0) {
      alert("Tu carrito está vacío.");
      return;
    }
    setPedidoEnviado(true);
    setTimeout(() => {
      onClearCart();
    }, 2500);
  };

  if (pedidoEnviado) {
    return (
      <div className="card shadow-sm p-5 text-center bg-white border-0 my-4">
        <h2 className="text-success fw-bold">🎉 ¡Pedido y Solicitud de Pago Recibidos!</h2>
        <p className="mt-3 fs-5">
          Gracias <strong>{formData.nombre} {formData.apellido}</strong> (RUT: {formData.rut}).
        </p>
        <p className="text-muted">
          Hemos procesado tu pago por un total de{" "}
          <strong className="text-danger">${totalCompra.toLocaleString("es-CL")}</strong>.
        </p>
        <div className="alert alert-light border d-inline-block text-start p-3 my-2">
          <small className="d-block fw-bold text-dark mb-1">📍 Dirección de Despacho Registrada:</small>
          <small className="d-block text-muted">
            {formData.direccion} #{formData.numero}, Comuna de {formData.comuna}, {formData.ciudad}.
          </small>
          <small className="d-block text-muted">Contacto: {formData.telefono}</small>
        </div>
        <div>
          <button className="btn btn-dark mt-3 fw-bold px-4" onClick={onVolverAlCatalogo}>
            Volver al Catálogo
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="row g-4">
      <div className="col-12 d-flex justify-content-between align-items-center">
        <h2 className="h3 fw-bold text-dark m-0">🛒 Tu Carrito de Compras</h2>
        <button className="btn btn-outline-secondary btn-sm" onClick={onVolverAlCatalogo}>
          ← Seguir Comprando
        </button>
      </div>

      {cartItems.length === 0 ? (
        <div className="col-12">
          <div className="card p-5 text-center border-0 shadow-sm">
            <h4 className="text-muted">El carrito se encuentra vacío.</h4>
            <div className="mt-3">
              <button className="btn btn-danger fw-bold" onClick={onVolverAlCatalogo}>
                Explorar Catálogo de Productos
              </button>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Productos en el Carrito */}
          <div className="col-lg-6">
            <div className="card shadow-sm border-0 p-3 bg-white">
              <h4 className="h5 fw-bold mb-3 border-bottom pb-2">Resumen de Productos</h4>
              <div className="table-responsive">
                <table className="table align-middle table-sm">
                  <thead>
                    <tr>
                      <th>Producto</th>
                      <th>Precio</th>
                      <th className="text-center">Cant.</th>
                      <th className="text-end">Subtotal</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {cartItems.map((item) => {
                      const numPrice = parsePrice(item.price);
                      return (
                        <tr key={item.id}>
                          <td>
                            <div className="d-flex align-items-center gap-2">
                              {item.image && (
                                <img
                                  src={item.image}
                                  alt={item.name}
                                  style={{ width: "40px", height: "40px", objectFit: "contain" }}
                                />
                              )}
                              <span className="fw-semibold small text-truncate" style={{ maxWidth: "140px" }}>
                                {item.name}
                              </span>
                            </div>
                          </td>
                          <td className="small">${numPrice.toLocaleString("es-CL")}</td>
                          <td className="text-center">
                            <div className="btn-group btn-group-sm">
                              <button
                                className="btn btn-outline-secondary py-0"
                                onClick={() => onUpdateQuantity(item.id, -1)}
                              >
                                -
                              </button>
                              <span className="btn btn-light disabled px-2 text-dark fw-bold py-0">
                                {item.quantity}
                              </span>
                              <button
                                className="btn btn-outline-secondary py-0"
                                onClick={() => onUpdateQuantity(item.id, 1)}
                              >
                                +
                              </button>
                            </div>
                          </td>
                          <td className="text-end fw-bold small">
                            ${(numPrice * item.quantity).toLocaleString("es-CL")}
                          </td>
                          <td className="text-end">
                            <button
                              className="btn btn-link text-danger p-0 border-0"
                              onClick={() => onRemoveItem(item.id)}
                            >
                              ✕
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <div className="d-flex justify-content-between align-items-center mt-3 pt-2 border-top">
                <span className="fw-bold fs-5">Total a Pagar:</span>
                <span className="fw-bold fs-4 text-danger">
                  ${totalCompra.toLocaleString("es-CL")}
                </span>
              </div>
            </div>
          </div>

          {/* Formulario Completo de Despacho con Selector de Datos de Registro */}
          <div className="col-lg-6">
            <div className="card shadow-sm border-0 p-4 bg-white">
              <h4 className="h5 fw-bold mb-2 border-bottom pb-2">🚚 Datos para Entrega por Despacho</h4>

              {/* Selector para autocompletar si hay usuario activo */}
              {currentUser && (
                <div className="form-check form-switch bg-light p-2 rounded border mb-3 ms-1">
                  <input
                    className="form-check-input ms-1 me-2"
                    type="checkbox"
                    id="chkRegistro"
                    checked={usarDatosRegistro}
                    onChange={handleToggleDatosRegistro}
                  />
                  <label className="form-check-label fw-bold text-primary small" htmlFor="chkRegistro">
                    ☑️ Usar mis datos de usuario registrado
                  </label>
                </div>
              )}

              <form onSubmit={handleSubmitSolicitud}>
                <div className="row g-2 mb-2">
                  <div className="col-6">
                    <label className="form-label small fw-semibold">Nombre</label>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      required
                      value={formData.nombre}
                      onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                      placeholder="Ej: Hitoshen"
                    />
                  </div>
                  <div className="col-6">
                    <label className="form-label small fw-semibold">Apellido</label>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      required
                      value={formData.apellido}
                      onChange={(e) => setFormData({ ...formData, apellido: e.target.value })}
                      placeholder="Ej: Hayashi"
                    />
                  </div>
                </div>

                <div className="row g-2 mb-2">
                  <div className="col-6">
                    <label className="form-label small fw-semibold">RUT de Recepción</label>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      required
                      value={formData.rut}
                      onChange={(e) => setFormData({ ...formData, rut: e.target.value })}
                      placeholder="Ej: 20059232-K"
                    />
                  </div>
                  <div className="col-6">
                    <label className="form-label small fw-semibold">Número de Teléfono</label>
                    <input
                      type="tel"
                      className="form-control form-control-sm"
                      required
                      value={formData.telefono}
                      onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                      placeholder="+56 9 1234 5678"
                    />
                  </div>
                </div>

                <div className="row g-2 mb-2">
                  <div className="col-8">
                    <label className="form-label small fw-semibold">Dirección (Calle)</label>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      required
                      value={formData.direccion}
                      onChange={(e) => setFormData({ ...formData, direccion: e.target.value })}
                      placeholder="Av. Providencia"
                    />
                  </div>
                  <div className="col-4">
                    <label className="form-label small fw-semibold">Número</label>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      required
                      value={formData.numero}
                      onChange={(e) => setFormData({ ...formData, numero: e.target.value })}
                      placeholder="1234"
                    />
                  </div>
                </div>

                <div className="row g-2 mb-3">
                  <div className="col-6">
                    <label className="form-label small fw-semibold">Comuna</label>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      required
                      value={formData.comuna}
                      onChange={(e) => setFormData({ ...formData, comuna: e.target.value })}
                      placeholder="Santiago"
                    />
                  </div>
                  <div className="col-6">
                    <label className="form-label small fw-semibold">Ciudad</label>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      required
                      value={formData.ciudad}
                      onChange={(e) => setFormData({ ...formData, ciudad: e.target.value })}
                      placeholder="Santiago"
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label small fw-semibold">Método de Pago</label>
                  <select
                    className="form-select form-select-sm"
                    value={formData.metodoPago}
                    onChange={(e) => setFormData({ ...formData, metodoPago: e.target.value })}
                  >
                    <option value="webpay">Webpay Plus (Débito / Crédito)</option>
                    <option value="transferencia">Transferencia Bancaria Directa</option>
                  </select>
                </div>

                <button type="submit" className="btn btn-success w-100 fw-bold py-2">
                  Ir al Pago (${totalCompra.toLocaleString("es-CL")})
                </button>
              </form>
            </div>
          </div>
        </>
      )}
    </div>
  );
};