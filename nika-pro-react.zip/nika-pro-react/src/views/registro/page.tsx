import React, { useState } from "react";

interface RegistroProps {
  onIrALogin: () => void;
}

// Validación de RUT Chileno (Algoritmo Módulo 11)
const validarRut = (cuerpo: string, dv: string): boolean => {
  const cuerpoLimpio = cuerpo.replace(/\./g, "").replace(/-/g, "").trim();
  if (!/^[0-9]+$/.test(cuerpoLimpio) || cuerpoLimpio.length < 7) return false;

  const dvIngresado = dv.trim().toUpperCase();
  let suma = 0;
  let multiplo = 2;

  for (let i = cuerpoLimpio.length - 1; i >= 0; i--) {
    suma += parseInt(cuerpoLimpio.charAt(i), 10) * multiplo;
    multiplo = multiplo === 7 ? 2 : multiplo + 1;
  }

  const dvEsperadoNum = 11 - (suma % 11);
  const dvEsperado = dvEsperadoNum === 11 ? "0" : dvEsperadoNum === 10 ? "K" : dvEsperadoNum.toString();

  return dvEsperado === dvIngresado;
};

// Generador de ID Único: Iniciales del Nombre/Apellido + Cuerpo del RUT
const generarIdUsuario = (nombreCompleto: string, cuerpoRut: string): string => {
  const partesNombre = nombreCompleto.trim().split(" ").filter(Boolean);
  const primerNombre = partesNombre[0] || "";
  const primerApellido = partesNombre[1] || "";

  const iniciales = (
    (primerNombre.charAt(0) || "") + (primerApellido.charAt(0) || "")
  ).toUpperCase();

  const cuerpoLimpio = cuerpoRut.replace(/\./g, "").replace(/-/g, "").trim();
  return `${iniciales}${cuerpoLimpio}`;
};

export const RegistroView: React.FC<RegistroProps> = ({ onIrALogin }) => {
  const [formData, setFormData] = useState({
    nombre: "",
    rutCuerpo: "",
    rutDv: "0",
    correo: "",
    password: "",
  });
  const [errorRut, setErrorRut] = useState("");
  const [idGenerado, setIdGenerado] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorRut("");

    if (!validarRut(formData.rutCuerpo, formData.rutDv)) {
      setErrorRut("El RUT o Dígito Verificador ingresado no es válido.");
      return;
    }

    const rutCompleto = `${formData.rutCuerpo}-${formData.rutDv}`;
    const userId = generarIdUsuario(formData.nombre, formData.rutCuerpo);

    // ADMINISTRADOR ÚNICO DESIGNADO: HH20059232
    const ID_ADMIN_DESIGNADO = "HH20059232";
    const esAdmin = userId === ID_ADMIN_DESIGNADO;
    const rolUsuario = esAdmin ? "admin" : "cliente";

    const nuevoUsuario = {
      id: userId,
      nombre: formData.nombre,
      rut: rutCompleto,
      correo: formData.correo,
      password: formData.password,
      role: rolUsuario,
    };

    const usuariosExistentes = JSON.parse(localStorage.getItem("nika_users") || "[]");
    usuariosExistentes.push(nuevoUsuario);
    localStorage.setItem("nika_users", JSON.stringify(usuariosExistentes));

    setIdGenerado(userId);

    setTimeout(() => {
      alert(`¡Cuenta Creada Éxitosamente!\nID asignado: ${userId}\nRol: ${rolUsuario.toUpperCase()}`);
      onIrALogin();
    }, 1200);
  };

  return (
    <div className="row justify-content-center">
      <div className="col-md-6">
        <div className="card shadow-sm p-4 bg-white border-0">
          <h2 className="h4 fw-bold text-center mb-4">📝 Crear Cuenta en Nika Gamer</h2>

          {idGenerado && (
            <div className="alert alert-success text-center">
              ¡Cuenta creada! Tu ID asignado es <strong>{idGenerado}</strong>.
            </div>
          )}

          {errorRut && <div className="alert alert-danger text-center">{errorRut}</div>}

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label fw-semibold">Nombre Completo</label>
              <input
                type="text"
                className="form-control"
                required
                value={formData.nombre}
                onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                placeholder="Ej: Hitoshen Hayashi"
              />
            </div>

            {/* RUT con Selector Desplegable de DV */}
            <div className="mb-3">
              <label className="form-label fw-semibold">RUT (Sin puntos ni guion)</label>
              <div className="input-group">
                <input
                  type="text"
                  className="form-control"
                  required
                  maxLength={8}
                  value={formData.rutCuerpo}
                  onChange={(e) => setFormData({ ...formData, rutCuerpo: e.target.value.replace(/\D/g, "") })}
                  placeholder="Ej: 20059232"
                />
                <span className="input-group-text fw-bold">-</span>
                <select
                  className="form-select text-center fw-bold"
                  style={{ maxWidth: "80px" }}
                  value={formData.rutDv}
                  onChange={(e) => setFormData({ ...formData, rutDv: e.target.value })}
                >
                  <option value="0">0</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="K">K</option>
                </select>
              </div>
              <div className="form-text">
                Selecciona tu dígito verificador en la casilla pequeña (0-9 o K).
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label fw-semibold">Correo Electrónico</label>
              <input
                type="email"
                className="form-control"
                required
                value={formData.correo}
                onChange={(e) => setFormData({ ...formData, correo: e.target.value })}
                placeholder="correo@ejemplo.cl"
              />
            </div>

            <div className="mb-3">
              <label className="form-label fw-semibold">Contraseña</label>
              <input
                type="password"
                className="form-control"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              />
            </div>

            <button type="submit" className="btn btn-danger w-100 fw-bold mt-2">
              Registrarse
            </button>
          </form>

          <div className="text-center mt-3">
            <small className="text-muted">
              ¿Ya tienes cuenta?{" "}
              <button className="btn btn-link p-0 text-danger text-decoration-none fw-semibold" onClick={onIrALogin}>
                Inicia sesión aquí
              </button>
            </small>
          </div>
        </div>
      </div>
    </div>
  );
};