import React from "react";

export interface Product {
  id: string;
  category: string;
  price: string;
  stocked: boolean;
  stockQuantity?: number;
  name: string;
  image?: string;
}

interface ProductosProps {
  products: Product[];
  filterText: string;
  inStockOnly: boolean;
  setInStockOnly: (val: boolean) => void;
  currentUser: { role: string } | null;
  onSelectProduct: (prod: Product) => void;
  onAddToCart: (prod: Product) => void;
  onUpdateStockQuantity?: (id: string, newStock: number) => void;
  onDeleteProduct?: (id: string) => void;
}

export const ProductosView: React.FC<ProductosProps> = ({
  products,
  filterText,
  inStockOnly,
  setInStockOnly,
  currentUser,
  onSelectProduct,
  onAddToCart,
  onUpdateStockQuantity,
  onDeleteProduct,
}) => {
  const esAdmin = currentUser?.role === "admin";

  const filteredProducts = products.filter((p) => {
    const matchesText =
      p.name.toLowerCase().includes(filterText.toLowerCase()) ||
      p.category.toLowerCase().includes(filterText.toLowerCase());
    const matchesStock = inStockOnly ? p.stocked : true;
    return matchesText && matchesStock;
  });

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <h2 className="h4 fw-bold m-0">📦 Catálogo de Componentes Gamer</h2>
        <div className="form-check form-switch">
          <input
            className="form-check-input"
            type="checkbox"
            id="stockCheck"
            checked={inStockOnly}
            onChange={(e) => setInStockOnly(e.target.checked)}
          />
          <label className="form-check-label fw-semibold" htmlFor="stockCheck">
            Mostrar solo productos con stock
          </label>
        </div>
      </div>

      <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-3">
        {filteredProducts.map((prod) => {
          const cantidadStock = prod.stockQuantity ?? (prod.stocked ? 5 : 0);

          return (
            <div className="col" key={prod.id}>
              <div className="card h-100 shadow-sm border-0 position-relative">
                <span className="badge bg-secondary position-absolute top-0 end-0 m-2">
                  {prod.category}
                </span>

                <img
                  src={prod.image}
                  alt={prod.name}
                  className="card-img-top p-3"
                  style={{ height: "180px", objectFit: "contain", cursor: "pointer" }}
                  onClick={() => onSelectProduct(prod)}
                  onError={(e) => {
                    (e.target as HTMLImageElement).src =
                      "https://via.placeholder.com/200x180?text=Sin+Imagen";
                  }}
                />

                <div className="card-body d-flex flex-column justify-content-between p-3">
                  <div>
                    <h6
                      className="card-title fw-bold text-dark text-truncate"
                      title={prod.name}
                      style={{ cursor: "pointer" }}
                      onClick={() => onSelectProduct(prod)}
                    >
                      {prod.name}
                    </h6>
                    <p className="card-text text-danger fw-bold fs-5 mb-1">{prod.price}</p>
                    
                    <small className={cantidadStock > 0 ? "text-success fw-bold d-block" : "text-danger fw-bold d-block"}>
                      {cantidadStock > 0 ? `✓ Unidades: ${cantidadStock}` : "✕ Agotado"}
                    </small>
                  </div>

                  {/* Acciones para el Cliente vs Acciones para el Admin */}
                  <div className="mt-3">
                    {esAdmin ? (
                      <div className="d-flex flex-column gap-2 bg-light p-2 rounded border">
                        <small className="fw-bold text-dark text-center">⚙️ Control Admin Stock</small>
                        <div className="input-group input-group-sm">
                          <span className="input-group-text">Cant:</span>
                          <input
                            type="number"
                            min="0"
                            className="form-control text-center fw-bold"
                            value={cantidadStock}
                            onChange={(e) =>
                              onUpdateStockQuantity &&
                              onUpdateStockQuantity(prod.id, parseInt(e.target.value, 10) || 0)
                            }
                          />
                        </div>
                        <button
                          className="btn btn-outline-danger btn-sm fw-bold w-100"
                          onClick={() => onDeleteProduct && onDeleteProduct(prod.id)}
                        >
                          🗑️ Eliminar Producto
                        </button>
                      </div>
                    ) : (
                      <div className="d-flex gap-2">
                        <button
                          className="btn btn-outline-dark btn-sm flex-grow-1"
                          onClick={() => onSelectProduct(prod)}
                        >
                          Ver Detalle
                        </button>
                        <button
                          className="btn btn-danger btn-sm text-white fw-bold"
                          disabled={cantidadStock <= 0}
                          onClick={() => onAddToCart(prod)}
                        >
                          + Agregar
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
