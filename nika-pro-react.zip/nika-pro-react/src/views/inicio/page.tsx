import React from "react";

interface InicioProps {
  onVerProductos: () => void;
}

export const InicioView: React.FC<InicioProps> = ({ onVerProductos }) => {
  return (
    <div>
      <div className="p-5 mb-4 bg-dark text-white rounded-3 shadow border border-secondary">
        <div className="container-fluid py-4">
          <span className="badge bg-danger mb-2">Setup Pro 2026</span>
          <h1 className="display-4 fw-bold text-light">Equipa tu Estación Gamer</h1>
          <p className="col-md-8 fs-5 text-muted">
            Los mejores componentes, periféricos mecánicos y tarjetas gráficas con envío rápido a todo Chile.
          </p>
          <button className="btn btn-danger btn-lg mt-2 fw-bold" onClick={onVerProductos}>
            Explorar Catálogo 🚀
          </button>
        </div>
      </div>

      <div className="row g-4 my-2">
        <div className="col-md-4">
          <div className="card h-100 p-3 shadow-sm text-center border-0 bg-white">
            <i className="bi bi-truck fs-1 text-danger"></i>
            <h5 className="fw-bold mt-2">Envíos a todo Chile</h5>
            <p className="text-muted small">Despacho garantizado para tus componentes.</p>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card h-100 p-3 shadow-sm text-center border-0 bg-white">
            <i className="bi bi-shield-check fs-1 text-danger"></i>
            <h5 className="fw-bold mt-2">Garantía Oficial</h5>
            <p className="text-muted small">Todos los productos cuentan con respaldo directo.</p>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card h-100 p-3 shadow-sm text-center border-0 bg-white">
            <i className="bi bi-credit-card fs-1 text-danger"></i>
            <h5 className="fw-bold mt-2">Pago Seguro</h5>
            <p className="text-muted small">Múltiples medios de pago integrados.</p>
          </div>
        </div>
      </div>
    </div>
  );
};