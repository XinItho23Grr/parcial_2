import React, { useState } from "react";

export const ContactoView: React.FC = () => {
  const [mensajeEnviado, setMensajeEnviado] = useState(false);

  return (
    <div className="row justify-content-center">
      <div className="col-md-7">
        <div className="card shadow-sm p-4 bg-white border-0">
          <h2 className="h4 fw-bold mb-3">📩 Contáctanos</h2>
          {mensajeEnviado && (
            <div className="alert alert-success">¡Mensaje enviado con éxito! Nos pondremos en contacto pronto.</div>
          )}
          <form onSubmit={(e) => { e.preventDefault(); setMensajeEnviado(true); }}>
            <div className="mb-3">
              <label className="form-label">Nombre</label>
              <input type="text" className="form-control" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Correo Electrónico</label>
              <input type="email" className="form-control" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Mensaje o Consulta</label>
              <textarea className="form-control" rows={4} required></textarea>
            </div>
            <button type="submit" className="btn btn-danger w-100 fw-bold">Enviar Consulta</button>
          </form>
        </div>
      </div>
    </div>
  );
};