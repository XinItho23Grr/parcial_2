import React from "react";

interface NavbarProps {
  filterText: string;
  setFilterText: (val: string) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
  currentUser: { id: string; nombre: string; role: string } | null;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  filterText,
  setFilterText,
  activeTab,
  setActiveTab,
  cartCount,
  currentUser,
  onLogout,
}) => {
  const esAdmin = currentUser?.role === "admin";

  const handleIrInicio = () => {
    if (esAdmin) {
      setActiveTab("admin");
    } else {
      setActiveTab("inicio");
    }
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
      <div className="container">
        <a
          className="navbar-brand fw-bold text-danger d-flex align-items-center gap-2"
          href="#inicio"
          onClick={(e) => {
            e.preventDefault();
            handleIrInicio();
          }}
        >
          ⚡ Nika Gamer Store
        </a>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarContent"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarContent">
          {!esAdmin && (
            <div className="mx-auto my-2 my-lg-0" style={{ width: "100%", maxWidth: "320px" }}>
              <input
                type="text"
                className="form-control form-control-sm"
                placeholder="🔍 Buscar componentes..."
                value={filterText}
                onChange={(e) => {
                  setFilterText(e.target.value);
                  if (activeTab !== "productos") setActiveTab("productos");
                }}
              />
            </div>
          )}

          <ul className={`navbar-nav ${esAdmin ? "ms-auto" : ""} align-items-center gap-2`}>
            <li className="nav-item">
              <button
                className={`btn btn-sm ${activeTab === (esAdmin ? "admin" : "inicio") ? "btn-danger" : "btn-outline-light"}`}
                onClick={handleIrInicio}
              >
                {esAdmin ? "📊 Mi Panel" : "Inicio"}
              </button>
            </li>
            <li className="nav-item">
              <button
                className={`btn btn-sm ${activeTab === "productos" ? "btn-danger" : "btn-outline-light"}`}
                onClick={() => setActiveTab("productos")}
              >
                Catálogo
              </button>
            </li>

            {!esAdmin && (
              <>
                <li className="nav-item">
                  <button
                    className={`btn btn-sm ${activeTab === "nosotros" ? "btn-danger" : "btn-outline-light"}`}
                    onClick={() => setActiveTab("nosotros")}
                  >
                    Nosotros
                  </button>
                </li>
                <li className="nav-item">
                  <button
                    className={`btn btn-sm ${activeTab === "contacto" ? "btn-danger" : "btn-outline-light"}`}
                    onClick={() => setActiveTab("contacto")}
                  >
                    Contacto
                  </button>
                </li>
                <li className="nav-item">
                  <button
                    className="btn btn-outline-light btn-sm position-relative"
                    onClick={() => setActiveTab("cart")}
                  >
                    🛒 Carrito
                    {cartCount > 0 && (
                      <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {cartCount}
                      </span>
                    )}
                  </button>
                </li>
              </>
            )}

            {/* Usuario autenticado (Menú desplegable único y limpio) */}
            {currentUser ? (
              <li className="nav-item dropdown ms-lg-2">
                <button
                  className="btn btn-secondary btn-sm dropdown-toggle fw-bold"
                  type="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  👤 {currentUser.nombre} ({currentUser.role.toUpperCase()})
                </button>
                <ul className="dropdown-menu dropdown-menu-end shadow">
                  <li className="dropdown-header fw-bold text-dark">
                    ID: {currentUser.id}
                  </li>
                  <li><hr className="dropdown-divider" /></li>
                  <li>
                    <button
                      className="dropdown-item text-danger fw-bold d-flex align-items-center gap-2"
                      onClick={onLogout}
                    >
                      🚪 Cerrar Sesión
                    </button>
                  </li>
                </ul>
              </li>
            ) : (
              <li className="nav-item">
                <button
                  className={`btn btn-sm ${activeTab === "login" ? "btn-danger" : "btn-outline-light"}`}
                  onClick={() => setActiveTab("login")}
                >
                  Iniciar Sesión
                </button>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
};
