import React, { useState } from "react";

interface Product {
  id: string;
  category: string;
  price: string;
  stocked: boolean;
  name: string;
}

interface AdminPanelProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ products, setProducts }) => {
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Teclados");
  const [price, setPrice] = useState("");
  const [stocked, setStocked] = useState(true);

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !price) return;

    const newProd: Product = {
      id: String(Date.now()),
      name,
      category,
      price: `$${price}`,
      stocked,
    };

    setProducts([...products, newProd]);
    setName("");
    setPrice("");
  };

  const handleDelete = (id: string) => {
    setProducts(products.filter((p) => p.id !== id));
  };

  return (
    <div className="card shadow-sm p-4 bg-white">
      <h2 className="h4 text-dark mb-4">🛠️ Panel de Administración (Gestión de Productos)</h2>

      {/* Formulario Agregar Producto */}
      <form onSubmit={handleAddProduct} className="row g-3 mb-5 p-3 border rounded bg-light">
        <h3 className="h6 text-primary">Agregar Nuevo Producto Gamer</h3>
        <div className="col-md-4">
          <input
            type="text"
            className="form-control"
            placeholder="Nombre del Producto"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div className="col-md-3">
          <select className="form-select" value={category} onChange={(e) => setCategory(e.target.value)}>
            <option value="Teclados">Teclados</option>
            <option value="Audífonos">Audífonos</option>
            <option value="Tarjetas Gráficas">Tarjetas Gráficas</option>
            <option value="Sillas Gamer">Sillas Gamer</option>
            <option value="Mouse">Mouse</option>
          </select>
        </div>
        <div className="col-md-3">
          <input
            type="text"
            className="form-control"
            placeholder="Precio (ej: 49990)"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
          />
        </div>
        <div className="col-md-2 d-flex align-items-center">
          <div className="form-check">
            <input
              type="checkbox"
              className="form-check-input"
              id="stockedAdmin"
              checked={stocked}
              onChange={(e) => setStocked(e.target.checked)}
            />
            <label className="form-check-label" htmlFor="stockedAdmin">En Stock</label>
          </div>
        </div>
        <div className="col-12 text-end">
          <button type="submit" className="btn btn-dark btn-sm">Guardar Producto</button>
        </div>
      </form>

      {/* Tabla Lista de Productos Admin */}
      <div className="table-responsive">
        <table className="table table-striped align-middle">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Categoría</th>
              <th>Precio</th>
              <th>Stock</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td>{p.id}</td>
                <td>{p.name}</td>
                <td><span className="badge bg-secondary">{p.category}</span></td>
                <td>{p.price}</td>
                <td>
                  {p.stocked ? (
                    <span className="badge bg-success">En Stock</span>
                  ) : (
                    <span className="badge bg-danger">Agotado</span>
                  )}
                </td>
                <td>
                  <button className="btn btn-danger btn-sm" onClick={() => handleDelete(p.id)}>
                    Eliminar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};