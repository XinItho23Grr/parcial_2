import React from "react";

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  return (
    <footer className="bg-dark text-light pt-5 pb-3 mt-auto border-top border-secondary">
      <div className="container">
        <div className="row g-4">
          {/* Columna 1: Marca y descripción */}
          <div className="col-md-4">
            <h5 className="fw-bold text-danger mb-3">⚡ Nika Gamer Store</h5>
            <p className="text-muted small">
              Tu tienda de confianza especializada en componentes, periféricos de alto rendimiento y equipamiento gamer en Chile.
            </p>
            <div className="d-flex gap-3 fs-5">
              <a href="#instagram" className="text-secondary text-decoration-none">
                <i className="bi bi-instagram"></i>
              </a>
              <a href="#facebook" className="text-secondary text-decoration-none">
                <i className="bi bi-facebook"></i>
              </a>
              <a href="#twitch" className="text-secondary text-decoration-none">
                <i className="bi bi-twitch"></i>
              </a>
              <a href="#discord" className="text-secondary text-decoration-none">
                <i className="bi bi-discord"></i>
              </a>
            </div>
          </div>

          {/* Columna 2: Enlaces Rápidos */}
          <div className="col-md-4">
            <h6 className="fw-bold text-uppercase mb-3 text-light">Navegación</h6>
            <ul className="list-unstyled text-muted small">
              <li className="mb-2">
                <button
                  className="btn btn-link text-decoration-none text-secondary p-0 border-0 btn-sm"
                  onClick={() => setActiveTab("inicio")}
                >
                  Inicio
                </button>
              </li>
              <li className="mb-2">
                <button
                  className="btn btn-link text-decoration-none text-secondary p-0 border-0 btn-sm"
                  onClick={() => setActiveTab("productos")}
                >
                  Catálogo de Productos
                </button>
              </li>
              <li className="mb-2">
                <button
                  className="btn btn-link text-decoration-none text-secondary p-0 border-0 btn-sm"
                  onClick={() => setActiveTab("nosotros")}
                >
                  Sobre Nosotros
                </button>
              </li>
              <li className="mb-2">
                <button
                  className="btn btn-link text-decoration-none text-secondary p-0 border-0 btn-sm"
                  onClick={() => setActiveTab("contacto")}
                >
                  Contacto y Soporte
                </button>
              </li>
            </ul>
          </div>

          {/* Columna 3: Información de Contacto y Métodos de Pago */}
          <div className="col-md-4">
            <h6 className="fw-bold text-uppercase mb-3 text-light">Contacto</h6>
            <p className="text-muted small mb-1">
              <i className="bi bi-geo-alt-fill text-danger me-2"></i> Santiago, Chile
            </p>
            <p className="text-muted small mb-1">
              <i className="bi bi-envelope-fill text-danger me-2"></i> contacto@nikagamer.cl
            </p>
            <p className="text-muted small mb-3">
              <i className="bi bi-clock-fill text-danger me-2"></i> Lun - Vie: 09:00 - 18:00 hrs
            </p>

            <h6 className="fw-bold text-uppercase mb-2 text-light fs-7">Medios de Pago</h6>
            <div className="d-flex gap-2 fs-4 text-secondary">
              <i className="bi bi-credit-card-2-front-fill" title="Débito / Crédito"></i>
              <i className="bi bi-bank2" title="Transferencia Bancaria"></i>
              <i className="bi bi-wallet2" title="Mercado Pago / Webpay"></i>
            </div>
          </div>
        </div>

        <hr className="my-4 border-secondary" />

        <div className="d-flex flex-column flex-sm-row justify-content-between align-items-center text-muted small">
          <p className="m-0">© {new Date().getFullYear()} Nika Gamer Store. Todos los derechos reservados.</p>
          <p className="m-0 text-secondary">Evaluación Parcial 2 - Duoc UC</p>
        </div>
      </div>
    </footer>
  );
};