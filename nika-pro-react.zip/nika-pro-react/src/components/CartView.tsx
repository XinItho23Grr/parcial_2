import React, { useState } from "react";

interface Product {
  id: string;
  category: string;
  price: string;
  stocked: boolean;
  name: string;
}

interface CartViewProps {
  onSuccessPay: () => void;
  onErrorPay: () => void;
}

export const CartView: React.FC<CartViewProps> = ({ onSuccessPay, onErrorPay }) => {
  const [formData, setFormData] = useState({
    nombre: "Hitoshen",
    apellido: "Lee",
    correo: "hitoshen@ejemplo.cl",
    calle: "Av. Principal 123",
    comuna: "Santiago",
  });

  return (
    <div className="card shadow-sm p-4 bg-white">
      <h2 className="h4 text-dark mb-4">🛒 Carrito de Compras & Checkout</h2>
      
      {/* Resumen de compra ficticio */}
      <div className="table-responsive mb-4">
        <table className="table table-bordered align-middle">
          <thead className="table-light">
            <tr>
              <th>Producto</th>
              <th>Precio</th>
              <th>Cantidad</th>
              <th>Subtotal</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Teclado Mecánico RGB Redragon</td>
              <td>$45.990</td>
              <td>1</td>
              <td className="fw-bold">$45.990</td>
            </tr>
          </tbody>
        </table>
      </div>

      <h3 className="h5 mb-3 text-secondary">Información de Envío</h3>
      <form onSubmit={(e) => e.preventDefault()} className="row g-3 mb-4">
        <div className="col-md-6">
          <label className="form-label">Nombre</label>
          <input
            type="text"
            className="form-control"
            value={formData.nombre}
            onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
          />
        </div>
        <div className="col-md-6">
          <label className="form-label">Apellido</label>
          <input
            type="text"
            className="form-control"
            value={formData.apellido}
            onChange={(e) => setFormData({ ...formData, apellido: e.target.value })}
          />
        </div>
        <div className="col-md-6">
          <label className="form-label">Correo Electrónico</label>
          <input
            type="email"
            className="form-control"
            value={formData.correo}
            onChange={(e) => setFormData({ ...formData, correo: e.target.value })}
          />
        </div>
        <div className="col-md-6">
          <label className="form-label">Dirección</label>
          <input
            type="text"
            className="form-control"
            value={formData.calle}
            onChange={(e) => setFormData({ ...formData, calle: e.target.value })}
          />
        </div>
      </form>

      <div className="d-flex gap-3 justify-content-end">
        <button className="btn btn-outline-danger" onClick={onErrorPay}>
          Simular Error de Pago ❌
        </button>
        <button className="btn btn-success fw-bold" onClick={onSuccessPay}>
          Pagar Ahora $45.990 💳
        </button>
      </div>
    </div>
  );
};